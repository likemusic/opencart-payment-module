<?php
$_['text_title']  = 'Credit Card / Debit Card';
$_['token_error'] = 'Error to create a payment token. Contact the store owner';
$_['text_order']  = 'Order #';
?>
